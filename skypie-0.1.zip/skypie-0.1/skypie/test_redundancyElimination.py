from skypie import *

def benchmark():
    # XXX: Random inequalities is not a good benchmark, since we are uncertain of their redundancy. Ideally, we want to control the number of redudant inequalities.
    no_dims=[100, 500, 800]
    no_inequalitiess=[10**3, 10**4, 10**5, 10**6]
    inequalities = np.random.rand(np.amax(no_inequalitiess), np.amax(no_dims))

    print(f"no_dims;no_inequalities;no_nonredundant;totalOptTime;totalExecTime")
    for no_dims, no_inequalities in itertools.product(no_dims, no_inequalitiess):
        start = time.time_ns()
        res = redundancyElimination(inequalities=inequalities[:no_inequalities, :no_dims], verbose=0, convert=False)
        totalExecTime = time.time_ns() - start
        nonredundant = [ i for i, (r, _) in enumerate(res) if r == True]
        optTime = [ t for _, t in res]
        totalOptTime = sum(optTime)
        #print("Redundant: ", redundant)
        #print("Exec time: ", execTime)
        #print("Total opt time: ", totalOptTime)
        #print("Total exec time: ", totalExecTime)
        print(f"{no_dims};{no_inequalities};{len(nonredundant)};{totalOptTime};{totalExecTime}")

def parseArgs(args, *, defaults=dict()):
    parsed = {
        "testCase" : 0,
        "verbose" : 4,
        "convert" : False,
        "normalize":NormalizationType.No, #.log10All #No #standardScoreColumnWise
        "lastColSpecial" : False, # Treat last column specially, i.e., as x' of the cost-workload halfplane
        "nonnegative":True,
        #"optimizerType":MosekOptimizerType.InteriorPoint
        "optimizerType":MosekOptimizerType.PrimalSimplex,
        "no_dim" : 2,
        "no_inequalities" : 3, #6000
        "clarkson":False,
        "standard":True,
        "useGPU":False,
        "optimizerThreads":1,
        "computeInteriorPoint":True,
        "lrs_benchmark":False,
    }

    for key, value in defaults.items():
        parsed[key] = value

    if len(args) <= 1:
        return parsed

    for arg in args[1:]:
        if "PrimalSimplex" in arg:
            parsed["optimizerType"] = MosekOptimizerType.PrimalSimplex
        elif "InteriorPoint" in arg:
            parsed["optimizerType"]=MosekOptimizerType.InteriorPoint
        elif "Free" in arg:
            parsed["optimizerType"]=MosekOptimizerType.Free
        elif "OptimizerThreads" in arg:
            parsed["optimizerThreads"]=int(arg.split("=")[1])
        elif "verbose" in arg:
            parsed["verbose"]=int(arg.split("=")[1])
        elif "nonnegative" in arg:
            parsed["nonnegative"] = ("False" not in arg)
        elif "clarkson" in arg:
            parsed["clarkson"] = ("False" not in arg)
            parsed["standard"] = not parsed["clarkson"]
        elif "standard" in arg:
            parsed["standard"] = ("False" not in arg)
            parsed["clarkson"] = not parsed["standard"]
        elif "useGPU" in arg:
            parsed["useGPU"] = ("False" not in arg)
        elif "testCase" in arg:
            parsed["testCase"] = int(arg.split("=")[1])
        elif "no_dim" in arg:
            parsed["no_dim"] = int(arg.split("=")[1])
        elif "no_inequalities" in arg:
            parsed["no_inequalities"] = int(arg.split("=")[1])
        elif "lrs_benchmark" in arg:
            parsed["lrs_benchmark"] = True
        else:
            raise RuntimeError("Unknown argument: " + arg)

    if parsed["verbose"] > 2:
        print("Parsed arguments: ", parsed)

    return parsed

def test_w_equality():
    defaultArgs = {
        "verbose" : 3,
        "convert" : False,
        "normalize":NormalizationType.No, #.log10All #No #standardScoreColumnWise
        "lastColSpecial" : False, # Treat last column specially, i.e., as x' of the cost-workload halfplane
        "nonnegative":True,
        "optimizerType":MosekOptimizerType.InteriorPoint,
        #"optimizerType":MosekOptimizerType.Free,
        #"standard":True,
        #"clarkson":False,
        #"useGPU":False,
        "optimizerThreads":1,
        #"computeInteriorPoint":True,
    }
    argsCase1 ={
        "inequalities": np.array([
            [1,1,0], # 1 >= 1x + 0y <- irredundant
            [2,1,0], # 2 >= 1x + 0y <- redundant
            [2,0,1], # 2 >= 0x + 1y <- redundant
            [1,0,1], # 1 >= 0x + 1y <- redundant
            [-0.1,-1,0] # 0.1 <= 1x + 0y <- irredundant
        ], dtype=np.float64),
        "equalities": np.array([
            [1,0,1] # 1 >= 0x + 1y <- irredundant
        ], dtype=np.float64),
        "knownIrredundant": [4]
    }
    expectedCase1 = [True, False, False, False, True]

    argsCase2 = dict(
    inequalities = np.array([
            [1,1,0], # 1 >= 1x + 0y <- redundant
            [2,1,0], # 2 >= 1x + 0y <- redundant
            [2,0,1], # 2 >= 0x + 1y <- redundant
            [1.5,1,1], # 1.5 >= 1.5x + 1.5y <- irredundant
        ], dtype=np.float64),
        equalities = np.array([
            [1,0,1] # 1 >= 0x + 1y <- irredundant
        ], dtype=np.float64)
    )
    expectedCase2 = [False, False, False, True]

    # Test with infeasible problem
    argsCase3 ={
        "inequalities": np.array([
            [1,1], # 1 >= 1x + 0y <- irredundant
            [2,1], # 2 >= 1x + 0y <- redundant
            #[2,0,1], # 2 >= 0x + 1y <- redundant
            #[1,0,1], # 1 >= 0x + 1y <- redundant
            [-2,-1] # 2 <= 1x + 0y <- irredundant
        ], dtype=np.float64),
        "equalities": np.array([
            [1,0] # 1 = 1x + 0y <- irredundant
        ], dtype=np.float64),
        "knownIrredundant": []
    }
    expectedCase3 = [False, False, False]

    for i, (argsCase, expected) in enumerate([(argsCase3, expectedCase3)]): #enumerate([(argsCase1, expectedCase1), (argsCase2, expectedCase2)]):
        for clarkson in [False]: #[True, False]:
            print("Case " + str(i) + ", clarkson=" + str(clarkson))
            if clarkson:
                res = redundancyEliminationClarkson(**argsCase, **defaultArgs)
            else:
                res = redundancyElimination(**argsCase, **defaultArgs)
            #print(res)
            if expected != [ r for r, _ in res]:
                print("Case " + str(i) + ", clarkson=" + str(clarkson) +" = ERROR, expected: " + str(expected) + ", got: " + str([ r for r, _ in res]))
            else:
                print("Case " + str(i) + ", clarkson=" + str(clarkson) +" = OK")

def compare_pareto():
    coefficients = [
        #[-3.0],
        #[-2.0]
        #[3, 0.5], # f_0(x,y) = 3x + .5y
        [0.5, 3], # f_1(x,y) = .5x + 3y
        [1.5, 1.5], # f_2(x,y) = 1.5x + 1.5y
        [2.5, 2.5] # f_2(x,y) = 1.5x + 1.5y
    ]
    inequalities = np.array([
        [0] + [ c*-1 for c in coefficients_i ] + [1] for coefficients_i in coefficients
    ])
    coefficients = np.array(coefficients)

    # torch.from_numpy(algoArgs["inequalities"][:,:-1])v
    res_re = redundancyElimination(inequalities=inequalities, nonnegative=True, verbose=3)
    res_p = compute_pareto_frontier(torch.from_numpy(coefficients), math=False)
    res_p2 = compute_pareto_frontier(torch.from_numpy(inequalities[:,1:-1]), math=False)
    print(f"Result redundancy: {res_re}")
    print(f"Result pareto: {res_p}")
    print(f"Result pareto: {res_p2}")

if __name__ == "__main__":
    
    #test_w_equality()

    compare_pareto()

    exit()

    properInteriorPoint=False
    interiorPoint=None
    expectedRedundant = set()

    if len(sys.argv) > 1:
        if sys.argv[1] == "lrs_benchmark":
            print("Running lrs_benchmark")

            defaults = {
                "testCase" : -1,
                "verbose" : 0,
                "convert" : False,
                "normalize":NormalizationType.No, #.log10All #No #standardScoreColumnWise
                "lastColSpecial" : True, # Treat last column specially, i.e., as x' of the cost-workload halfplane
                "nonnegative":False,
                #"optimizerType":MosekOptimizerType.InteriorPoint
                "optimizerType":MosekOptimizerType.Free,
                "standard":True,
                "clarkson":False,
                "useGPU":False,
                "optimizerThreads":1,
                "computeInteriorPoint":True,
            }
            
            args = parseArgs(sys.argv, defaults=defaults)

            # Read inequalities in lrs format from stdin
            inequalities = []
            parse=False
            for line in sys.stdin:
                if "end" in line:
                    break
                elif "begin" in line:
                    # Dump next line
                    sys.stdin.readline()
                    parse=True
                elif parse:
                    inequalities.append([
                        np.double(s) if not "/" in s else np.double(s.split("/")[0])/np.double(s.split("/")[1]) for s in line.strip().split(" ") if s != "" and s != " "
                    ])

            inequalities = np.array(inequalities)
            # Convert from lrs/cdd fromat (-A'x <= b) to ours A'x <= b
            inequalities[:, 1:] *= -1

            if args["verbose"] > 2:
                print("Inequalities:")
                print(inequalities)

        else:
            args=parseArgs(sys.argv)
    else:
        args = parseArgs(list())

    testCase = args["testCase"]
    verbose = args["verbose"]
    convert = args["convert"]
    normalize = args["normalize"]
    lastColSpecial = args["lastColSpecial"]
    nonnegative = args["nonnegative"]
    computeInteriorPoint = args["computeInteriorPoint"]
    clarkson = args["clarkson"]
    useGPU = args["useGPU"]
    standard = args["standard"]
    optimizerType = args["optimizerType"]
    optimizerThreads = args["optimizerThreads"]
    no_dim = args["no_dim"]
    no_inequalities = args["no_inequalities"]
    
    if testCase == 0:
        normalize = NormalizationType.No # Skip normalization for this test case

        # Ax <= b, b = [1,2,...,|x|+1],
        inequalities = np.ones(shape=(no_inequalities, no_dim), dtype=np.double)
        inequalities[:, 0] = range(1, no_inequalities+1)

        # Redundancy elimination with Clarkson's LP+ray-shooting algorithm
        # Interior point must properly be a point in the interior of the polytope. Here, we just use the origin and shift it a bit in each dimension.
        interiorPoint = np.zeros_like(inequalities[0], dtype=np.double)
        interiorPoint[0] = 1
        interiorPoint[1:] = 0.1

        expectedRedundant = set(range(1,len(inequalities)))

    elif testCase == 7:
        test_w_equality()
        exit(0)
    elif testCase == 1:
        normalize = NormalizationType.No # Skip normalization for this test case
        nonnegative = False # Allow negative values for this test case

        inequalities = np.array([
            [5, -1],
            [0, -1]
        ], dtype=np.double)

        #interiorPoint = np.array([3,3], dtype=np.double)
        interiorPoint = None

        expectedRedundant = {0}

    elif testCase in [2,5,6]:
        # One half-hyper-cube within another one. a_i*x_i <= 1
        # H1 is at distance 1/d from the axis: d*x_i <= 1 -> x_i <= 1/d
        # H2 is at distance 1/(d*epsilon) from axis: d*epsilon*x_i <= 1 -> x_i <= 1/(d*epsilon) 
        # For epsilon > 1: H2 is inside H1, i.e., H2 is nonredundant
        # For epsilon < 1: H1 is inside H2, i.e., H1 is nonredundant

        # Test case 2 for very close inequalites
        # Test case 5 for far inequalities
        # Test case 6 for very far inequalities
        d = 0.5
        epsilon = 0
        if testCase == 2:
            epsilon = 1 + 10**-5
        elif testCase == 5:
            epsilon = 10**7
        elif testCase == 6:
            epsilon = 10**9 # This is failing
        
        inequalities = np.zeros(shape=((no_dim-1)*2, no_dim))
        inequalities[:,0] = 1
        for i in range(1, no_dim):
            # inequality of H1
            inequalities[i-1,i] = d
            # inequality of H2
            inequalities[no_dim-1+i-1,i] = (d*epsilon)

        # Trying interior point hack, -1 is kind of in the half-cube, when the x>=0 constraints are ignored
        interiorPoint = np.full_like(inequalities[0], fill_value=0)
        #interiorPoint[-1] = -1
        if properInteriorPoint:
            interiorPoint[:] = 0.000001

        #if normalize in [NormalizationType.log10All, NormalizationType.log10ColumnWise]:
        #    # 0 -> 0, 1-> ?
        #    #inequalities *= 10 # Avoid coefficients == 1 in the data
        #    pass

        # The outer half-hyper-cude is redudant, H2
        expectedRedundant = set(range(no_dim-1))

    elif testCase == 3:
        lastColSpecial = True
        # b + x_1 + x_2 + x_3 >= 0
        ineq1 = np.array([0.0, 0.024, 1e-05, 1e-06, 1e-06, 1e-06, 1e-06, 0.02, 0.02, 0.02, 0.138, 0.166, 0.166, 0.166, 0.166, -1.0])
        ineq2 = np.array(ineq1)
        ineq2[0] = 1
        inequalities = np.vstack((ineq2, ineq1))

        #interiorPoint *= 10000
        interiorPoint = np.full_like(inequalities[0], fill_value=0.0001)
        interiorPoint[0] = 1
        interiorPoint[-1] = -1.0

        if args["convert"]:
            #inequalities = -inequalities
            inequalities[:,1:] *= -1

        print(inequalities)
        print(interiorPoint)

        expectedRedundant = {0}

    elif testCase == 4:
        print("Correctnes test")

        cddRationalInput = """0 0.023 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.01 0.02 0.02 0.02 0 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.01 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 -1 
0 0.025 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 0.086 -1 
0 0.026 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.1 0.1 0.1 0.08 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0 0.09 0.098 0.02 0.02 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.1805 0.07 0.1805 0.1805 0.1805 0.1805 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0 0.098 0.02 0.02 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.08 0.17 0.17 0.17 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.01 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.01 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.227 0.227 0.227 0.227 0.08 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 0.227 -1 
0 0.025 4.5e-06 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 3.5e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 0.08 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0 0.02 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.03 0.05 -1 
0 0.023 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0 0.02 0.02 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.04 0.138 0.138 -1 
0 0.0125 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.01 0.02 0.02 0.02 0 0.1105 0.09 0.098 0.02 0.02 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.05 0.06 0.06 0.06 0.04 0.06 0.06 0.06 0.06 0.06 -1 
0 0.023 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0 0.02 0.02 0.02 0.01 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.01 0.02 0.02 0.02 0.02 0.02 -1 
0 0.0326 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.148 0.148 0.148 0.148 0.148 0.148 0.01 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 0.148 -1 
0 0.0125 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0 0.02 0.02 0.02 0.01 0.1105 0.09 0.098 0.02 0.02 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.01 0.03 0.03 0.03 0.02 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0252 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0274 6e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.147 0.147 0.147 0.147 0 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 0.147 -1 
0 0.025 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0 0.098 0.02 0.02 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0 0.09 0.09 0.09 -1 
0 0.0125 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.05 0.03 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.11 0.11 0.02 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.13 0.13 0.13 0.13 0.13 0.04 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 -1 
0 0.025 5.5e-06 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0 0.02 0.02 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0.098 0 0.098 0.098 -1 
0 0.0245 5.4e-06 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 4.3e-07 0.02 0.02 0.09 0 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.03 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.024 5.3e-06 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 0 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.17 0.17 0.17 0.17 0.17 0.08 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 -1 
0 0.024 5.3e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.0131 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0 0.02 0.1105 0.09 0.098 0.02 0.02 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.04 0.06 0.06 0.06 0.06 0.06 0.06 -1 
0 0.025 5.5e-06 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 -1 
0 0.024 5.3e-06 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 4.2e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.0131 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.04 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 0.06 -1 
0 0.0405 7e-06 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 5.6e-07 0.02 0.02 0.09 0.02 0.147 0.09 0 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.138 0.138 0.138 0.138 0.138 0.138 0 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 0.138 -1 
0 0.025 4.7e-06 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 0.02 0.02 0 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.09 0.09 0 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0 0.02 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.08 0.1 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.17 0.17 0.08 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 0.17 -1 
0 0.025 4.7e-06 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 3.7e-07 0.02 0.02 0.09 0.02 0.147 0 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.09 0.09 0.09 0.09 0.09 0 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 -1 
0 0.023 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 -1 
0 0.0251 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.01 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0 0.098 0.02 0.02 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.13 0.04 0.13 0.13 0.13 -1 
0 0.0125 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.02 -1 
0 0.0144 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.05 0.03 0.05 0.05 0.05 0.05 0.05 0.05 0.05 -1 
0 0.0131 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0252 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0 0.02 0.1105 0.09 0.098 0.02 0.02 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.01 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0221 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.178 0.178 0.178 0.178 0.178 0.178 0.04 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 -1 
0 0.0149 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.177 0.177 0.177 0.177 0.03 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 0.177 -1 
0 0.0125 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.02 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0 0.09 0.098 0.02 0.02 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.1205 0.01 0.1205 0.1205 0.1205 0.1205 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.01 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 0.096 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0135 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.03 0.03 0.03 0.01 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 0.03 -1 
0 0.0138 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.03 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 0.11 -1 
0 0.025 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 0.09 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.02 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 -1 
0 0.023 5e-06 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 4e-07 0.02 0 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.01 0.02 0.02 0.02 0 0.1105 0.09 0.098 0.02 0.02 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.09 0.1 0.1 0.1 0.08 0.1 0.1 0.1 0.1 0.1 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.07 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 0.16 -1 
0 0.0264 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0 0.02 0.02 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.178 0.08 0.178 0.178 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0 0.02 0.02 0.02 0.01 0.1105 0.09 0.098 0.02 0.02 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.1 0.08 0.1 0.1 0.1 0.09 0.1 0.1 0.1 0.1 0.1 -1 
0 0.024 1e-05 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 1e-06 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0 0.02 0.02 0.02 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.08 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 0.166 -1 
0 0.025 5.5e-06 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0.02 0.02 0.02 0 0.09 0.098 0.02 0.02 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0.1105 0 0.1105 0.1105 0.1105 0.1105 -1 
0 0.026 5.5e-06 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 4.4e-07 0.02 0.02 0.09 0.02 0.147 0.09 0.138 0.02 0.09 0.08 0.086 0.02 0.02 0 0.02 0.02 0.1105 0.09 0.098 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0.02 0 0.02 0.02 0.02 0.02 0.02 0.02 0.02 -1"""
        
        lastColSpecial = True

        # Convert to floating point matrix
        inequalities = np.array(
            [ [ np.double(i) for i in s.strip().split(" ")] for s in cddRationalInput.splitlines()]
        )

        #Convert from A'x <= b to Ax + b >= 0
        if args["convert"]:
            #inequalities = -inequalities
            inequalities[:,1:] *= -1

        no_dim = inequalities.shape[1]
        interiorPoint = np.full(no_dim, dtype=np.double, fill_value=0)
        #interiorPoint[:] = 0.0001
        interiorPoint[-1] = -1.0

        interiorPoint = None

        print(inequalities)
        print(interiorPoint)

        expectedRedundant = set([int(i)-1 for i in "4 7 9 12 14 15 16 17 18 19 23 24 25 26 27 28 29 31 33 35 37 45 46 47 48 50 52 56 57 62 64 130".split(" ")])

    if computeInteriorPoint:
        interiorPoint = None

    if verbose > 0:
        print(inequalities)
        print(interiorPoint)

    print("Starting...")

    nonredundant2 = None
    nonredundant3 = None
    if clarkson:
        # Clarkson's with GPU
        if useGPU and torch.cuda.is_available():
            timerClarksonGPU = Timer()
            res3 = redundancyEliminationClarkson(inequalities=inequalities, interiorPointOrig=interiorPoint, convert=convert, verbose=verbose, torchDeviceRayShooting="cuda:4", normalize=normalize, nonnegative=nonnegative, lastColSpecial=lastColSpecial, optimizerThreads=optimizerThreads, timer=timerClarksonGPU)
            nonredundant3 = [ i for i, (r, _) in enumerate(res3) if r == True]
            redundant3 = [ i for i, (r, _) in enumerate(res3) if r == False]
            #execTime3 = np.sum([e for (_,e) in res3])
            print(f"Clarkson GPU in {timerClarksonGPU.getTotalTime()} ns\nwith compute time {timerClarksonGPU.getComputationTime()} ns\nNonredundant {len(nonredundant3)}: {nonredundant3}\nRedundant: {len(redundant3)}: {redundant3}")
            if expectedRedundant:
                print(f"False positive redundant: {set(redundant3) - expectedRedundant}")
                print(f"False negative redundant: {expectedRedundant - set(redundant3)}")
        
        # Clarkson's with CPU
        timerClarkson = Timer()
        res2 = redundancyEliminationClarkson(inequalities=inequalities, interiorPointOrig=interiorPoint, verbose=verbose, normalize=normalize, nonnegative=nonnegative, lastColSpecial=lastColSpecial, optimizerType=optimizerType, optimizerThreads=optimizerThreads, timer=timerClarkson)
        nonredundant2 = [ i for i, (r, _) in enumerate(res2) if r == True]
        redundant2 = [ i for i, (r, _) in enumerate(res2) if r == False]
        print(f"Clarkson in {timerClarkson.getTotalTime()} ns\nwith compute time {timerClarkson.getComputationTime()} ns\nNonredundant {len(nonredundant2)}: {nonredundant2}\nRedundant {len(redundant2)}: {redundant2}")
        if expectedRedundant:
            print(f"False positive redundant: {set(redundant2) - expectedRedundant}")
            print(f"False negative redundant: {expectedRedundant - set(redundant2)}")

    if standard:
        # Standard redundancy elimination
        timerStandard = Timer()
        res = redundancyElimination(inequalities=inequalities, verbose=verbose, normalize=normalize, nonnegative=nonnegative, lastColSpecial=lastColSpecial, optimizerType=optimizerType, optimizerThreads=optimizerThreads, timer=timerStandard)
        nonredundant = [ i for i, (r, _) in enumerate(res) if r == True]
        redundant = [ i for i, (r, _) in enumerate(res) if r == False]
        print(f"Standard in {timerStandard.getTotalTime()} ns\nwith compute time {timerStandard.getComputationTime()} ns\nNonredundant {len(nonredundant)}: {nonredundant}\nRedundant {len(redundant)}: {redundant}")
        if expectedRedundant:
            print(f"False positive redundant: {set(redundant) - expectedRedundant}")
            print(f"False negative redundant: {expectedRedundant - set(redundant)}")
    
    # XXX: Also standard redundancy elimination is unreliable, so is neither is the source of truth! Better use redund of cdd
    #assert nonredundant == nonredundant2, "nonredundant != nonredundant2"
    if nonredundant2 and nonredundant3:
        assert nonredundant3 == nonredundant2, "nonredundant3 != nonredundant2"