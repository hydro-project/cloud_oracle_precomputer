import setuptools

#with open("README.md", "r") as fh:
#    long_description = fh.read()


setuptools.setup(
     name='skypie',  
     version='0.1',
     #scripts=['test'] ,
     #author="Deepak Kumar",
     #author_email="deepak.kumar.iet@gmail.com",
     description="A package containing all python code of SkyPIE",
     #long_description=long_description,
     #long_description_content_type="text/markdown",
     #url="https://github.com/javatechy/dokr",
     install_requires=["cvxpy", "Mosek", "numpy", "torch", "pandas"],
     packages=setuptools.find_packages(),
     #classifiers=[
     #    "Programming Language :: Python :: 3",
     #    "License :: OSI Approved :: MIT License",
     #    "Operating System :: OS Independent",
     #],
 )