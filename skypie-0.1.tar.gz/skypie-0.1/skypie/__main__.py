from .oracle import __main__
if __name__ == "__main__":
    __main__()