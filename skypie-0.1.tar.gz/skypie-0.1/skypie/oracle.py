from dataclasses import dataclass, field
from typing import *
import json
from abc import ABC, abstractmethod
import torch
import numpy as np
import argparse
import pandas as pd
import copy
from multiprocessing import Pool
import bz2
import pickle
import dataclasses
from ast import literal_eval

from .my_dataclasses import *
from .redundancyEliminationMosek import *

from .horizonControlOptimizer import recendingHorizonControl, Problem

def deltaEncode(x: "List[int]"):
    """
    Delta encode a list of integers.
    """
    last = 0
    for i in x:
        yield i - last
        last = i

def deltaDecode(x: "List[int]"):
    """
    Delta decode a list of integers.
    """
    last = 0
    for i in x:
        last += i
        yield last

# https://stackoverflow.com/questions/27265939/comparing-python-dictionaries-and-nested-dictionaries
def findDiff(d1, d2, path=""):
    result = []
    for k in d1:
        if k in d2:
            if type(d1[k]) is dict:
                result.extend(findDiff(d1[k],d2[k], "%s -> %s" % (path, k) if path else k))
            if d1[k] != d2[k]:
                result.extend([ "%s: " % path, " - %s : %s" % (k, d1[k]) , " + %s : %s" % (k, d2[k])])
                #print("\n".join(result))
        else:
            #print ("%s%s as key not in d2\n" % ("%s: " % path if path else "", k))
            result.append("%s%s as key not in d2\n" % ("%s: " % path if path else "", k))
    return result

class OracleInterface(ABC):
    @abstractmethod
    def prepare_schemes(self, oracle: "Oracle"):
        pass

    @abstractmethod
    def query(self, w: "Workload|List[Workload]", timer: Timer = None) -> "List[float, OptimizationResult|int]":
        pass

    @abstractmethod
    def verify(self, w: "Workload|List[Workload]", schemeIndex: int, timer: Timer = None) -> "torch.Tensor":
        pass

@dataclass
class OracleImplMosek:
    networkPriceFileName: str
    storagePriceFileName: str
    strictReplication: bool = True
    minReplicationFactor: int = 0
    __problem: Problem = field(init=False)
    __oracle: "Oracle" = field(init=False)
    __problemArgs: Dict[str, Any] = field(init=False, default_factory=dict)

    def prepare_schemes(self, oracle: "Oracle"):
        """
        Extract the replication factor and other parameters from the scenarion.
        Then load  the problem
        """

        self.__oracle = oracle

        storageLoad = oracle.get_object_stores_considered()
        applicationRegionLoad = oracle.get_application_regions()
        minReplicationFactor = (int(oracle.get_scenario()["min_replication_factor"]) if self.minReplicationFactor <= 0 else self.minReplicationFactor)-1
        if self.strictReplication:
            maxReplicationFactor = int(oracle.get_scenario()["max_replication_factor"])-1
        else:
            maxReplicationFactor = len(oracle.get_object_stores_considered())
        problemArgsNow = {"storagePriceFileName": self.storagePriceFileName, "networkPriceFileName": self.networkPriceFileName, "applicationRegionLoad": applicationRegionLoad, "storageLoad": storageLoad, "min_f": minReplicationFactor, "max_f": maxReplicationFactor, "verbose": oracle.verbose}
        doLoad = len(self.__problemArgs) < 1 or not np.all([k in problemArgsNow and v == problemArgsNow[k] for k, v in self.__problemArgs.items()])
        if doLoad:
            self.__problem = Problem(**problemArgsNow)
            self.__problemArgs = problemArgsNow
        else:
            # We can reuse the problem as is, the arguments are the same
            pass

    def query(self, w: "Workload|List[Workload]", timer: Timer = None) -> "List[float, OptimizationResult]":
        """
        This function solves an integer linear program for the optimal scheme for the given workload, using Mosek.
        XXX: It supports batching.
        It returns the list of indexes of the optimal schemes.

        TODO: Batching by computing for workloads over time without migration costs, but we need the individual opt. values for the workloads.
        """

        if isinstance(w, Workload):
            w = [w]

        # Result
        res = []

        for workload in w:            
            print(f"Query done: {len(res)}/{len(w)}")
            sys.stdout.flush()
            self.__problem.setWorkload(workload)
            res.append(recendingHorizonControl(**self.__problem.__dict__, withRouting = False, withMigrationCosts=False, timer=timer))

            if self.__oracle.verbose > 1:
                print(self.__problem)
                res[-1].__dict__["problem"] = copy.deepcopy(self.__problem)

            print(f"Query done: {len(res)}/{len(w)}")
            sys.stdout.flush()
        
        # Without migration costs solving for a list of workloads is equivalent to batching, except that the opt. val is the total over all workloads...
        #self.__problem.setWorkload(w)
        #res = recendingHorizonControl(**self.__problem.__dict__, withRouting = False, withMigrationCosts=False, timer=timer)

        return [ (r.value, res) for r in res]

    def verify(self, w: "Workload|List[Workload]", schemeIndex: int) -> "torch.Tensor":
        pass

@dataclass
class OracleImplPyTorch(OracleInterface):
    device_query: str = "cpu" # We can query for the optimal scheme using different device types, e.g., "cpu" or gpu ("cuda:0")
    device_check: str = "cpu" # We can check the optimal scheme using different device types, e.g., "cpu" or gpu ("cuda:0")
    dataType: "torch.dtype" = torch.float64
    __queryData: "torch.Tensor" = field(default_factory=lambda: torch.tensor([])) # Tensor of shape: 1 x schemes x len(costWLHalfplane)
    __checkData: "torch.Tensor" = field(default_factory=lambda: torch.tensor([])) # Tensor of shape: schemes x 1 x inequalities (i.e., neighbors x len(cost))
    __shipToQueryDevice: bool = False
    
    def prepare_schemes(self, oracle: "Oracle"):
        schemes = oracle.get_schemes()
        self.__prepare_query_pytorch(schemes=schemes)
        # FIXME!!!
        #self.__prepare_check_pytorch(schemes=schemes)

    def __prepare_query_pytorch(self, schemes: "List[ReplicationScheme]"):
        """
        For the argmin implementation, we need to have the cost coefficients of all partitions in a single matrix.
        This function prepares the matrix and the device.
        """

        # Convert into single matrix
        matrix = np.array([scheme.costWorkloadHalfplane[:-1] for scheme in schemes])
        # and wrapping the matrix into another dimension for batching
        matrix.shape = (1, matrix.shape[0], matrix.shape[1])

        # Create a tensor from the matrix and ship it to the device
        self.__queryData = torch.tensor(data=matrix, dtype=self.dataType, device=self.device_query)

        self.__shipToQueryDevice = "cpu" not in self.device_query

    def query(self, w: "Workload|List[Workload]", timer: Timer = None) -> "List[Tuple[float, int]]":
        """
        This function queries the oracle for the optimal scheme for the given workload, using pytorch.
        It supports batching.
        It returns the list of indexes of the optimal schemes.
        The current implementation is the simple argmin brute force over the cost of all schemes.
        """

        if timer is not None:
            timer.continueOverhead()

        if isinstance(w, Workload):
            w = [w]
        
        # Convert workload into tensor
        if isinstance(w, np.ndarray) and not isinstance(w[0], Workload):
            workloadVectorLocal = torch.tensor(data=w, dtype=self.dataType)
        else:
            workloadVectorLocal = torch.tensor(data=[workload.equation for workload in w], dtype=self.dataType)
        # reshape for batching and ship to device
        workloadVectorDevice = workloadVectorLocal.reshape(workloadVectorLocal.shape[0], workloadVectorLocal.shape[1], 1)
        if self.__shipToQueryDevice:
            workloadVectorDevice = workloadVectorDevice.to(self.device_query)

        if timer is not None:
            timer.continueComputation()

        # Compute cost of each scheme for all workloads and return the index of the cheapest scheme
        res = torch.matmul(self.__queryData, workloadVectorDevice).min(dim=1)
        #optChoice = torch.matmul(self.__queryData,workloadVectorDevice).argmin(dim=1) #.squeeze(dim=-1)

        if timer is not None:
            timer.stop()

        #optValue = torch.matmul(self.__queryData[:,:,optChoice], workloadVectorDevice).squeeze(dim=-1)
        #optChoice = optChoice.squeeze()

        return list(zip(res.values.squeeze(dim=-1).tolist(), res.indices.squeeze(dim=-1).tolist()))

    def __prepare_check_pytorch(self, schemes: "List[ReplicationScheme]"):
        """"
        Convert the partition details into a tensor and ship them to the device.
        """
        localMatrixBatchList = np.array([[scheme.inequalities] for scheme in schemes], dtype=self.dataType)
        assert len(localMatrixBatchList.shape) == 4
        assert localMatrixBatchList.shape[0] == len(schemes)
        assert localMatrixBatchList.shape[1] == 1
        assert localMatrixBatchList.shape[3] == len(schemes[0].inequalities.shape[1])

        self.__checkData = torch.tensor(data=localMatrixBatchList, dtype=self.dataType, device=self.device_check)

    def verify(self, w: "Workload|List[Workload]", schemeIndex: int) -> "torch.Tensor":
        """"
        This function verifies if the given scheme is the optimal scheme for the given workload(s).
        It checks if the workload is still in the partition of the scheme using the precomputed partition details.
        This implementation only uses polytope inequalities to check, i.e., it does not use the ellipsoid approximation.
        It returns True if the scheme is optimal, False otherwise.
        """

        # Convert workload into tensor
        if isinstance(w, Workload):
            w = [w]
        
        # Get tensor of this schemes workload partition
        workloadVectorLocal = torch.tensor(data=[workload.equation for workload in w], dtype=self.dataType)
        # reshape for batching and shipt to device
        workloadVectorDevice = workloadVectorLocal.reshape(workloadVectorLocal.shape[0], workloadVectorLocal.shape[1], 1).to(self.device_query)

        # Check if any inequality is violated by this workload
        # XXX: Check if the condition is correct
        return (self.__checkData[schemeIndex].matmul(workloadVectorDevice) < 0.0).any(dim=1).squeeze(dim=-1)

@dataclass
class Oracle:
    inputFileName: str
    scenarioName: str = field(init=False, default=None)
    verbose: int = -1
    optimizerType: "OptimizerType" = field(init=False, default=None) #= field(default=OptimizerType(type="None"))
    no_apps = -1
    __instance: OracleInterface = field(init=False, default=None)
    __precomputedData: Dict[str, Any] = field(init=False, default=None)
    __scenario: Any = field(init=False, default=None)
    __replicationSchemes: List[ReplicationScheme] = field(init=False, default_factory=list)
    # Name of the appliction region and its index for the workload
    __applicationRegions: Dict[str, int] = field(init=False, default_factory=list)
    __objectStoresConsidered: List[str] = field(init=False, default_factory=list)
    __precomputationOptimizers: List[OptimizerType] = field(init=False, default_factory=list)
    # Name of optimizer whose incidence information is loaded
    __incidenceOptimizerType: OptimizerType = field(init=False, default=None)
    # Incidence information which schemes are inner neighbors
    __incidence: Dict[int, List[int]] = field(init=False, default_factory=dict)


    def __post_init__(self):
        readMode = "rb" if "pickle" in self.inputFileName else "r"
        if self.inputFileName.endswith("bz2"):
            f = bz2.BZ2File(self.inputFileName, readMode)
        else:
            f = open(self.inputFileName, readMode)
        if "pickle" in self.inputFileName:
            self.__precomputedData = pickle.load(f)
        else:
            self.__precomputedData = json.load(f, cls=EnhancedJSONDecoder)
        f.close()
        
        self.optimizerType = None
        self.__scenario = None
        self.__candidateSchemes = None
        self.__applicationRegions = dict()
        self.__objectStoresConsidered = list()

        #if self.scenarioName:
        #   self.prepare_scenario(scenarioName=self.scenarioName, optimizerType=self.optimizerType)

    def hasOptimalPartitions(self) -> bool:
        return len(self.__replicationSchemes) > 0

    def discoverOptimizerTypes(self, scenarioName: str) -> "List[OptimizerType]":
        scenario = self.__precomputedData
        precomputationOptimizers = list()
        for key in scenarioName.split("/"):
            if "relative" in key:
                pos = int(key.split("=")[1])
                key = list(scenario.keys())[pos]
            scenario = scenario[key]
        
        if "optimal_partitions_by_optimizer" in scenario:
            print(scenario["optimal_partitions_by_optimizer"].keys())
            for optimizer in scenario["optimal_partitions_by_optimizer"]:
                # Lrs does not provide details about the optimizer type, so we have to create one
                if "Lrs" in optimizer:
                    precomputationOptimizers.append(OptimizerType(implementation=OracleType.PYTORCH, type=optimizer))
                else:
                    # Load optimizer type from precomputed data
                    optimizerData = scenario["optimal_partitions_by_optimizer"][optimizer]["optimizer_type"]
                    
                    if isinstance(optimizerData, str) and "type" in optimizerData and "implementation" in optimizerData:
                        optimizerData = json.loads(optimizerData)
                        
                    if isinstance(optimizerData, dict):
                        optimizerData["type"] = MosekOptimizerType.from_str(optimizerData["type"])
                        optimizerData["implementation"] = OracleType(optimizerData["implementation"])
                        optimizerData = scenario["optimal_partitions_by_optimizer"][optimizer]["optimizer_type"] = OptimizerType(**optimizerData)
                        
                    precomputationOptimizers.append(optimizerData)

        return precomputationOptimizers
    
    def discoverOptimizerTypesIncidence(self, scenarioName: str, optimizerType: "OptimizerType") -> "List[OptimizerType]":
        scenario = self.__precomputedData
        incidenceOptimizers = list()
        for key in scenarioName.split("/"):
            if "relative" in key:
                pos = int(key.split("=")[1])
                key = list(scenario.keys())[pos]
            scenario = scenario[key]
        
        if "optimal_partitions_by_optimizer" in scenario and optimizerType.name in scenario["optimal_partitions_by_optimizer"]:
            data = scenario["optimal_partitions_by_optimizer"][optimizerType.name]
            if "incidence_by_optimizer" in data:
                print(data["incidence_by_optimizer"].keys())
                for optimizer in data["incidence_by_optimizer"]:
                    #optimizerData = scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimizer_type"]
                    optimizerData = data["incidence_by_optimizer"][optimizer]["optimizer_type"]
                    if isinstance(optimizerData, dict):
                        optimizerData["type"] = MosekOptimizerType.from_str(optimizerData["type"])
                        optimizerData["implementation"] = OracleType(optimizerData["implementation"])
                        # Convert to OptimizerType and write back
                        optimizerData = scenario["optimal_partitions_by_optimizer"][optimizer]["optimizer_type"] = OptimizerType(**optimizerData)
                
                    incidenceOptimizers.append(optimizerData)
            else:
                print(f"No incidence information found for optimizer: {optimizerType.name}")
        else:
            print(f"No optimal partitions found for optimizer: {optimizerType.name}")

        return incidenceOptimizers

    def set_neighborhood(self, name, data: Dict[str, Any]):
        if not "incidence_by_optimizer" in self.__scenario["optimal_partitions_by_optimizer"][self.optimizerType.name]:
            self.__scenario["optimal_partitions_by_optimizer"][self.optimizerType.name]["incidence_by_optimizer"] = dict()
        self.__scenario["optimal_partitions_by_optimizer"][self.optimizerType.name]["incidence_by_optimizer"][name] = data

    def prepare_scenario(self, scenarioName: str, optimizerType: "OptimizerType", repairInputData: bool = False, skipInstance = False, incidenceOptimizerType: "OptimizerType|None" = None):
        """
        This function prepares the oracle for a specific scenario from the input file.
        FIXME: Assignments are not correctly parsed!
        """

        # Instantiate OracleImplementation if implementation or implementationArgs changed
        if not skipInstance and ((self.optimizerType is None) or (optimizerType.implementation != self.optimizerType.implementation or self.optimizerType.implementationArgs != optimizerType.implementationArgs)):
            print("Switching OracleImplementation: ", optimizerType.implementation)
            if optimizerType.implementation == OracleType.PYTORCH:
                self.__instance = OracleImplPyTorch(**optimizerType.implementationArgs)
            elif optimizerType.implementation == OracleType.MOSEK:
                self.__instance = OracleImplMosek(**optimizerType.implementationArgs)
            else:
                raise Exception(f"Unknown OracleType: {optimizerType.implementation}")

        self.optimizerType = optimizerType

        if self.scenarioName != scenarioName:
            self.scenarioName = scenarioName
            self.__scenario = self.__precomputedData
            for key in scenarioName.split("/"):
                if "relative" in key:
                    pos = int(key.split("=")[1])
                    key = list(self.__scenario.keys())[pos]
                self.__scenario = self.__scenario[key]
            if "candidate_partitions" in self.__scenario and len(self.__scenario["candidate_partitions"]) > 0:
                self.__candidateSchemes = [ ReplicationScheme(p) for p in self.__scenario["candidate_partitions"]]
                self.__applicationRegions = self.__candidateSchemes[0].applictionRegionMapping #{ app:index for index, app in enumerate(self.__candidateSchemes[0].assignments) }

            # Discover optimizer types for this scenario
            self.__precomputationOptimizers = self.discoverOptimizerTypes(scenarioName)

            if "object_stores_considered" in self.__scenario:
                self.__objectStoresConsidered = self.__scenario["object_stores_considered"]

        if optimizerType.type == "Candidates":
            # Use candidate partitions to query optima. The result is still optimal, but the computation takes longer.
            if len(self.__candidateSchemes) > 0:
                self.__replicationSchemes = self.__candidateSchemes
            else:
                raise Exception("No candidate partitions found in scenario")
        elif "optimal_partitions_by_optimizer" in self.__scenario and \
            optimizerType.name in self.__scenario["optimal_partitions_by_optimizer"] and \
            ("optimal_partition_ids" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name] and len(self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partition_ids"]) > 0 or \
            "optimal_partition_ids_delta" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name] and len(self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partition_ids_delta"]) > 0 or \
            "optimal_partitions" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name] and len(self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partitions"]) > 0 
            ):

            if "optimal_partitions" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]:

                temp = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partitions"]
                if isinstance(temp, str) and temp.endswith(".jsonl"):
                    # Load optimal partitions from referenced file, line by line
                    with open(temp, "r") as f:
                        self.__replicationSchemes = [ReplicationScheme(json.loads(line)) for line in f]
                else:
                    # Load optimal partitions
                    self.__replicationSchemes = [ ReplicationScheme(s) for s in temp]
            else:
                if "optimal_partition_ids_delta" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]:
                    # Decompress delta encoded optimal partition ids
                    optimal_partition_ids = deltaDecode(self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partition_ids_delta"])
                else:
                    # Take raw optimal partition ids
                    optimal_partition_ids = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partition_ids"]
                
                # Load incidence information of this optimizer
                if incidenceOptimizerType and "incidence_by_optimizer" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["incidence_by_optimizer"]:
                #self.__scenario["optimal_partitions_by_optimizer"][self.optimizerType.name]["incidence_by_optimizer"][name]
                    self.__incidence = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["incidence_by_optimizer"][incidenceOptimizerType.name]['incident_partitions_id']
                    self.__incidenceOptimizerType = incidenceOptimizerType
                else:
                    self.__incidence = dict()
                    self.__incidenceOptimizerType = None


                # Restore optimal partitions from candidate partitions
                self.__replicationSchemes = [ ReplicationScheme(self.__scenario["candidate_partitions"][pID]) for pID in optimal_partition_ids]
                print("Restored optimal partitions by id")

        #elif optimizerType.type != "None" and optimizerType.type != "ILP" and "optimal_partitions_by_optimizer" in self.__scenario and optimizerType.name in self.__scenario["optimal_partitions_by_optimizer"] and len(self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partitions"]) > 0:
        #    self.__replicationSchemes = [ ReplicationScheme(p) for p in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["optimal_partitions"]]
        elif "optimal_partitions" in self.__scenario and len(self.__scenario["optimal_partitions"]) > 0:
            self.__replicationSchemes = [ ReplicationScheme(p) for p in self.__scenario["optimal_partitions"]]
            print("Falling back to default optimal partitions by unknown optimizer.")

        if self.hasOptimalPartitions() and len(self.__replicationSchemes[0].assignments) > 1:
            self.__applicationRegions = { app:index for index, app in enumerate(self.__replicationSchemes[0].assignments) }

        if len(self.__applicationRegions) == 0 and "applictionRegionMapping" in self.__scenario:
            self.__applicationRegions = self.__scenario["applictionRegionMapping"]

        self.no_apps = int(self.__scenario["no_app_regions"])
        assert self.no_apps == len(self.__applicationRegions) or len(self.__applicationRegions) == 0, f"Number of application regions in scenario {self.no_apps} does not match number of application regions in optimal partitions {len(self.__applicationRegions)}"

        if repairInputData:
            self.repairInputData()

        # Mosek does not need the precomputed optimal partitions
        if not skipInstance and (self.hasOptimalPartitions() or optimizerType.implementation == OracleType.MOSEK):
            self.__instance.prepare_schemes(oracle=self)
        else: 
            print(f"WARNING: No optimal partitions found in scenario for optimizer {optimizerType}. The optimal partitons have to be computed from the candidate partitions or the candidate partitions can be used directly.")

    def query(self, w: "Workload|List[Workload]", timer: Timer = None, translateOptSchemes: bool = False, rescale: np.float64 = np.float64(1)) -> "List[Tuple[float,int|ReplicationScheme]]":
        # Get the optimal partition for the given workload
        res = self.__instance.query(w, timer=timer)

        if translateOptSchemes:
            res = [ (r[0],{r[1]:self.__replicationSchemes[r[1]]}) if isinstance(r[1], (int, np.number)) else r for r in res ]

        # Rescale costs for scaled workloads
        if rescale != 1.0:
            res = [ (r[0]/rescale,r[1]) for r in res ]

        return res


    def verify(self, w: "Workload|List[Workload]", schemeIndex: int) -> "bool":
        """
        This function verifies if the given scheme is the optimal scheme for the given workload(s).
        It either takes the index of a repliction scheme.
        For each workload it returns True if the scheme is optimal, False otherwise.
        """
        # FIXME
        return self.__instance.verify(w, scheme)

    def get_schemes(self) -> List[ReplicationScheme]:
        return self.__replicationSchemes
    
    def get_incidences(self) -> Dict[int, List[int]]:
        return self.__incidence
    
    def get_instance(self) -> OracleInterface:
        return self.__instance

    def get_candidate_schemes(self) -> List[ReplicationScheme]:
        return self.__candidateSchemes

    def get_application_regions(self) -> Dict[str, int]:
        return self.__applicationRegions

    def get_object_stores_considered(self) -> bool:
        return self.__objectStoresConsidered

    def get_scenario(self) -> Dict:
        return self.__scenario
    
    def get_precomputation_optimizers(self) -> List[OptimizerType]:
        return self.__precomputationOptimizers

    def repairInputData(self):
        """
        This function repairs the input data.
        It checks the formulation of the costHalfplanes for the correct sign and repairs the sgin if necessary.
        The expected signs are positive for all workload dimensions and negative for the extra cost dimension.
        """

        if self.__candidateSchemes is None:
            return

        for scheme in self.__candidateSchemes:
            for index, value in enumerate(scheme.costWorkloadHalfplane):
                if (index == len(scheme.costWorkloadHalfplane) - 1 and value < 0) or (index == len(scheme.costWorkloadHalfplane) - 1 and value > 0):
                    scheme.costWorkloadHalfplane[index] = -value

    def compute_optima(self,*, divisionSize: "int|None"=None, iterations=1000, candidateLimit: "int|None"=None, processes: int=1, optimizerType: "OptimizerType" = OptimizerType(type=MosekOptimizerType.InteriorPoint, useClarkson=True, useGPU=True), algoArgs: "Dict[str, Any]" = {"torchDeviceRayShooting": "cpu", "normalize": NormalizationType.No, "nonnegative" : True, "optimizerThreads": 1}):

        if self.verbose > 0:
            print("Computing optimal partitions with arugments:")
            print(f"\tdivisionSize: {divisionSize}")
            print(f"\titerations: {iterations}")
            print(f"\tcandidateLimit: {candidateLimit}")
            print(f"\tprocesses: {processes}")
            print(f"\toptimizerType: {optimizerType}")
            print(f"\talgoArgs: {algoArgs}")
            sys.stdout.flush()

        """
        This function computes the optimal partitions for the current scenario.
        It filters the candidate partitions for those that are optimal for some workload.

        Note that this function only updates the scenario data.
        For using the updated data, the scenario has to be prepared again!
        The data neither is persisted! The data has to be written back for persistence!

        The computation either uses a acurrate one-shot or the divide-and-pause approach.
        One-shot:
        If divisonSize or iterations is None, then optimal partitions are computed in a single step,
        resulting in the actual minimal set of optimal partitions
        Divide-and-pause:
        If a divisionSize and iterations are given, then the candidates are divided into groups which are separately filtered.
        The filtered result again is divided into groups and filtered again, until the number of iterations is reached.
        Notably, the final set of partitions is not minimal (containing some non-optimal partitions),
        but the computation is much faster and still permits optimal queries.

        XXX: Importantly, redundancy elimination currently does not compute an interior point on it's own,
        but requires an interior point to be given!
        This interior point must lie strictly within the polytope of the cost-workload halfplanes!
        Currently, this interior point is hacked as -1 cost and epsilon workload,
        exploiting that the cost-worklaod halfplanes are all in the positive orthant
        and the lower bound planes are ignored when the point lies outside their halfspace.
        The hacked interior point seems sufficient for all our uses cases,
        though when it is insufficient it causes silent catastrophic corruption!

        Algo args:
        torchDeviceRayShooting
        nonnegative
        normalize
        optimizerThreads
        """

        if not self.__candidateSchemes:
            print("No candidate schemes found.")
            return

        optimizerTypeName = optimizerType.name

        doDivide = divisionSize is not None and iterations is not None

        """
        Convert candidate schemes to single tensor of inequalities:
        - Add lower bound of 0 workload and cost, i.e., for each dimension: x_i >= 0
        - Get costWLhalfplanes of each scheme
        - (Optionally: Add upper bound of bigM cost)
        """

        no_dim = len(self.__candidateSchemes[0].costWorkloadHalfplane)

        if candidateLimit is None:
            candidateLimit = len(self.__candidateSchemes)
        
        inequalities = np.vstack([s.costWorkloadHalfplane for s in self.__candidateSchemes[:candidateLimit]])

        assert inequalities.shape[1] == no_dim
        assert inequalities.shape[0] == len(self.__candidateSchemes[:candidateLimit]) #+ no_dim - 1

        interiorPoint = None

        if optimizerType.useGPU == False:
            algoArgs["torchDeviceRayShooting"] = "cpu"
        elif optimizerType.useGPU and "cuda" in algoArgs.get("torchDeviceRayShooting", "") and not torch.cuda.is_available():
            raise RuntimeError("cuda is unavailable, but requested for rayshooting")

        '''
        Divide-and-pause approach:
        If a divisionSize and iterations are given, then the candidates are divided into groups which are separately filtered.
        After each iteration, the redundant inequalities are removed and the non-redundant inequalities are used as new candidates.

        In the first iteration, the candidates are divided into groups of size divisionSize.
        In the subsequent iterations, the filtered result is assigned random groups.
        The original candidate ids have to be stored for the final result.
        '''

        if doDivide:
            timer = Timer()
            wallTimer = Timer()

            for nonredundant3, redundant3, localOptimizerType in parallelRedundancyElimination(processes=processes, iterations=iterations, divisionSize=divisionSize, interiorPoint=interiorPoint,inequalities=inequalities, algoArgs=algoArgs,optimizerType=optimizerType, verbose=self.verbose, timer=timer, wallTimer=wallTimer):

                # Give total wall clock time of redundancy elimination
                clarksonDuration = timer.getTotalTime()

                # Save result under name of optimizer type, batch size and iteration
                # Copy non redundant candidates to optimal
                if "optimal_partitions_by_optimizer" not in self.__scenario:
                    self.__scenario["optimal_partitions_by_optimizer"] = dict()

                name = localOptimizerType.name #+ "_dsize" + str(divisionSize) + "_iter" + str(i)
                self.__scenario["optimal_partitions_by_optimizer"][name] = dict()
                result = self.__scenario["optimal_partitions_by_optimizer"][name]
                result["optimizer_type"] = localOptimizerType
                # Save optimal partitions
                result["optimal_partitions"] = []
                #for pos in nonredundant3:
                #    result["optimal_partitions"].append(self.__scenario["candidate_partitions"][pos])

                # Write back additional stats
                # Number of optimal repliction schemes
                no_facets = len(nonredundant3)
                result["no_facets"] = no_facets
                # Number of redundnat repliction schemes
                result["no_redundant_facets"] = len(redundant3)
                # Ids of optimal repliction schemes
                result["optimal_partition_ids_delta"] = list(deltaEncode(nonredundant3))
                # Ids of redundant repliction schemes
                result["nonoptimal_partition_ids_delta"] = list(deltaEncode(redundant3))
                # Time for computing the optimal repliction schemes/partitions
                result["partitioner_wall_time_ns"] = wallTimer.getOverheadTime() # Wall clock time overall
                result["partitioner_time_ns"] = timer.getTotalTime() # Time of parallel processes total (overhead+compute) 
                result["partitioner_computation_time_ns"] = timer.getComputationTime() # Time of parallel processes for computation 

                if self.verbose > 0:
                    print(result)
                print(f"Redundancy elimination done. {no_facets} facets found, after {wallTimer.getOverheadTime()/1e9:.2f} seconds (wall clock time).")

        else:
            timer=Timer()
            if optimizerType.useClarkson:
                res3 = redundancyEliminationClarkson(inequalities=inequalities, interiorPointOrig=interiorPoint, verbose=self.verbose, optimizerType=optimizerType.type, timer=timer, **algoArgs)
            else:
                res3 = redundancyElimination(inequalities=inequalities, verbose=self.verbose, optimizerType=optimizerType.type, timer=timer, **algoArgs)

            # Get ids of nonredundant/optimal and redundant/nonoptimal partitions and ignore the additional bounds
            nonredundant3 = [ i for i, (r, _) in enumerate(res3[:len(self.__candidateSchemes)]) if r == True]
            redundant3 = [ i for i, (r, _) in enumerate(res3[:len(self.__candidateSchemes)]) if r == False]
            clarksonDuration = timer.getTotalTime()
            if self.verbose > 0:
                print(f"Redundancy elimination by {optimizerType.name} in {clarksonDuration} ns\nwith compute time {timer.getComputationTime()} ns\nNonredundant {len(nonredundant3)}: {nonredundant3}")

            # Save result under name of optimizer type
            # Copy non redundant candidates to optimal
            if "optimal_partitions_by_optimizer" not in self.__scenario:
                self.__scenario["optimal_partitions_by_optimizer"] = dict()

            self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name] = dict()
            result = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]
            result["optimizer_type"] = optimizerType
            # Save optimal partitions
            result["optimal_partitions"] = []
            #for i in nonredundant3:
            #    result["optimal_partitions"].append(self.__scenario["candidate_partitions"][i])

            # Write back additional stats
            # Number of optimal repliction schemes
            no_facets = len(nonredundant3)
            result["no_facets"] = no_facets
            # Number of redundnat repliction schemes
            result["no_redundant_facets"] = len(redundant3)
            # Ids of optimal repliction schemes
            result["optimal_partition_ids_delta"] = list(deltaEncode(nonredundant3))
            # Ids of redundant repliction schemes
            result["nonoptimal_partition_ids_delta"] = list(deltaEncode(redundant3))
            # Time for computing the optimal repliction schemes/partitions
            result["partitioner_time_ns"] = clarksonDuration
            result["partitioner_computation_time_ns"] = timer.getComputationTime()

            if self.verbose > 0:
                print(result)

    def compute_neighborhood(self,*, divisionSize: "int|None"=None, iterations=1, processes: int=1, optimizerType: "OptimizerType" = OptimizerType(type=MosekOptimizerType.InteriorPoint, useClarkson=False, useGPU=False), algoArgs: "Dict[str, Any]" = {"torchDeviceRayShooting": "cpu", "normalize": NormalizationType.No, "nonnegative" : True, "optimizerThreads": 1}):

        if self.verbose > 0:
            print("Computing optimal partitions with arugments:")
            print(f"\tdivisionSize: {divisionSize}")
            print(f"\titerations: {iterations}")
            print(f"\tprocesses: {processes}")
            print(f"\toptimizerType: {optimizerType}")
            print(f"\talgoArgs: {algoArgs}")
            sys.stdout.flush()

        """
        This function computes the which optimal partitions are inner neighbors for the current scenario.
        This is a very similar algorithm to compute_optima!

        Note that this function only updates the scenario data.
        For using the updated data, the scenario has to be prepared again!
        The data neither is persisted! The data has to be written back for persistence!

        The computation either uses a acurrate one-shot or the divide-and-pause approach.
        One-shot:
        If divisonSize or iterations is None, then optimal partitions are computed in a single step,
        resulting in the actual minimal set of optimal partitions
        Divide-and-pause:
        If a divisionSize and iterations are given, then the candidates are divided into groups which are separately filtered.
        The filtered result again is divided into groups and filtered again, until the number of iterations is reached.
        Notably, the final set of partitions is not minimal (containing some non-optimal partitions),
        but the computation is much faster and still permits optimal queries.

        Algo args:
        torchDeviceRayShooting
        nonnegative
        normalize
        optimizerThreads
        """

        if not self.__replicationSchemes or len(self.__replicationSchemes) == 0:
            print(f"No optimal replication schemes found! (Did you run compute_optima() for this optimizer {optimizerType}?)")
            return

        doTest = False
        if doTest:
            inequalities = np.array([
                [1,1,0], # 1 >= 1x + 0y <- irredundant
                [3,1,0], # 2 >= 1x + 0y <- redundant
                [3,0,1], # 2 >= 0x + 1y <- redundant
                [1,0,1], # 1 >= 0x + 1y <- redundant
                [-0.1,-1,0] # 0.1 <= 1x + 0y <- irredundant
            ])
        else:
            no_dim = len(self.__replicationSchemes[0].costWorkloadHalfplane)
            
            inequalities = np.vstack([s.costWorkloadHalfplane for s in self.__replicationSchemes])

            assert inequalities.shape[1] == no_dim
            assert inequalities.shape[0] == len(self.__replicationSchemes) #+ no_dim - 1

        interiorPoint = None

        if optimizerType.useGPU == False:
            algoArgs["torchDeviceRayShooting"] = "cpu"
        elif optimizerType.useGPU and "cuda" in algoArgs.get("torchDeviceRayShooting", "") and not torch.cuda.is_available():
            raise RuntimeError("cuda is unavailable, but requested for rayshooting")

        if not doNormalCompute:
            algoArgs["overestimate"] = False

        timer = Timer()
        wallTimer = Timer()

        """
        # Compute neighborhood of optimal partitions using redundancy elimination,
        # i.e., irredudant partitions are neighbors of each other
        Loop over each partition and gradually annotate the neighbors:
        - Set costplane of partition under check as equality
        - Pass in known neighbors as hint
        - Compute all its neighbors
        - Add itself as neighbor to all its neighbors
        """

        neighbors = { i : set() for i in range(inequalities.shape[0])}

        pool = Pool(processes=processes)

        for current_index in range(inequalities.shape[0]):
            # Set costplane of partition under check as equality
            algoArgs["equalities"] = inequalities[current_index:current_index+1,:]
            knownIrredundant = neighbors[current_index] | {current_index}

            tight_neighbors = set()
            for tight_neighbors, _redundant, _localOptimizerType in parallelRedundancyElimination(knownIrredundant=knownIrredundant, processes=processes, iterations=iterations, divisionSize=divisionSize, interiorPoint=interiorPoint,inequalities=inequalities, algoArgs=algoArgs,optimizerType=optimizerType, verbose=self.verbose, timer=timer, wallTimer=wallTimer, pool=pool):
                pass
            # We don't care about the information of the individual iterations here, simply take the final
            neighbors[current_index] = set(tight_neighbors)
            
            if current_index in neighbors[current_index]:
                neighbors[current_index].remove(current_index) # Remove itself as neighbor

            # Add itself as neighbor to all its neighbors
            for neighbor in neighbors[current_index]:
                neighbors[neighbor].add(current_index)     

        # Save result under name of optimizer type, batch size and iteration
        localOptimizerType = optimizerType.custom_copy(dsize=divisionSize)
        name = localOptimizerType.name
        result = dict()
        result["optimizer_type"] = localOptimizerType
        # Ids of optimal repliction schemes
        result["incident_partitions_id"] = neighbors
        # Time for computing the optimal repliction schemes/partitions
        result["incidence_wall_time_ns"] = wallTimer.getOverheadTime() # Wall clock time overall
        result["incidence_time_ns"] = timer.getTotalTime() # Time of parallel processes total (overhead+compute) 
        result["incidence_computation_time_ns"] = timer.getComputationTime() # Time of parallel processes for computation 

        self.set_neighborhood(name, result)

        if self.verbose > 0:
            print(result)

        pool.close()

    def dumpCDD(self, inequalities):
        print("Input for cdd:")
        print(f"H-representation\nbegin\n{inequalities.shape[0]} {inequalities.shape[1]} real")
        for i in range(inequalities.shape[0]):
            for j in range(inequalities.shape[1]):
                if j == 0:
                    print(f"{inequalities[i,j]} ", end="")
                else:
                    print(f"{-inequalities[i,j]} ", end="")
            print()
        print("end")

    def validate_precomputed(self, baseline, comp):
        raise NotImplementedError("TODO")

        # Use precomputed incides of optima for validation

        # Check if precomputed indices of optimal and nonoptimal candidate partitions are available
        nonredundant = self.__scenario.get("optimal_partition_ids", [])
        redundant = self.__scenario.get("nonoptimal_partition_ids", [])

        if len(nonredundant) == 0:
            if len(redundant) > 0:
                print("restoring missing optimal_partition_ids from nonoptimal_partition_ids")
                allIDs = set(range(len(self.__candidateSchemes)))
                nonredundant = allIDs - set(redundant)
            else:
                print("optimal_partition_ids missing for validation!")

        if len(redundant) == 0:
            if len(nonredundant) > 0:
                print("restoring missing nonoptimal_partition_ids from optimal_partition_ids")
                allIDs = set(range(len(self.__candidateSchemes)))
                redundant = allIDs - set(nonredundant)
            else:
                print("nonoptimal_partition_ids missing for validation!")

        # Validate
        validNonredundant = (nonredundant == nonredundant3)
        validRedundant = (redundant == nonredundant3)
        validRedundantCdd = (redundant == expectedRedundant)
        print("Optimal partition ids valid: ", validNonredundant)
        print("Nonoptimal partition ids valid: ", validRedundant)
        print("CDD Nonoptimal partition ids valid: ", validRedundantCdd)

        if not validNonredundant:
            print("Found optimal partition ids:   ", nonredundant3)
        
        if not validRedundant:
            print("Found nonoptimal partition ids:   ", redundant3)

        if not validRedundantCdd and expectedRedundant and len(expectedRedundant) > 0:
            cddExpectedRedundantSet = set(expectedRedundant)
            print("CDD Missing nonoptimal partition ids:", cddExpectedRedundantSet - set(redundant))

    def save(self, output: str):
        # Temporarily remove the optimal partitions of all optimizers
        #backup = { "optimal_partitions_by_optimizer": self.__scenario.get("optimal_partitions_by_optimizer", None) }

        if output is None or output == "":
            json.dumps(self.__precomputedData, cls=EnhancedJSONEncoder, indent=4)
        else:
            print("Writing out to " + output)
            if output.endswith(".pickle"):
                with open(output, "wb") as f:
                    pickle.dump(self.__precomputedData, f)
            else:
                with open(output, "w") as f:
                    json.dump(self.__precomputedData, f, cls=EnhancedJSONEncoder, indent=4)

        # restore the optimal partitions of all optimizers

    def get_precomputation_times(self,*, optimizerType: "OptimizerType|None" = None):

        if optimizerType is None:
            optimizerType = self.optimizerType

        res = dict()
        # Enumeraiton time of scenario
        res["Enumeration Time (ns)"] = self.__scenario["enumerator_time_ns"]

        # Time for computing the optimal repliction schemes/partitions with current optimizer
        if "optimal_partitions_by_optimizer" in self.__scenario and optimizerType.name in self.__scenario["optimal_partitions_by_optimizer"]:
            res["Partition Time (ns)"] = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["partitioner_time_ns"]
            res["Partition Time - Compute Only (ns)"] = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["partitioner_computation_time_ns"]
            if "partitioner_wall_time_ns" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]:
                res["Partition Wall Time (ns)"] = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["partitioner_wall_time_ns"]
        else:
            res["Partition Time (ns)"] = self.__scenario["partitioner_time_ns"]
            res["Partition Time - Compute Only (ns)"] = res["Partition Time (ns)"]
            if "partitioner_wall_time_ns" in self.__scenario:
                res["Partition Wall Time (ns)"] = self.__scenario["partitioner_wall_time_ns"]

        res["Partition Time (ns)"] = max(0, int(res["Partition Time (ns)"]))
        res["Partition Time - Compute Only (ns)"] = max(0, int(res["Partition Time - Compute Only (ns)"]))

        if not "Partition Wall Time (ns)" in res:
            res["Partition Wall Time (ns)"] = res["Partition Time (ns)"]

        return res
    
    def get_incidence_stats(self, *, optimizerType: "OptimizerType", incidenceOptimizerType):
        res = dict()
        if "optimal_partitions_by_optimizer" in self.__scenario and \
                optimizerType.name in self.__scenario["optimal_partitions_by_optimizer"] and \
                "incidence_by_optimizer" in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name] and \
                incidenceOptimizerType.name in self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["incidence_by_optimizer"]:
            result = self.__scenario["optimal_partitions_by_optimizer"][optimizerType.name]["incidence_by_optimizer"][incidenceOptimizerType.name]
            # Number of incidences
            incidences_per_scheme = [len(indicences) for indicences in result["incident_partitions_id"].values()]
            no_incidences = 0
            for indicences in incidences_per_scheme:
                no_incidences += indicences
            res["Number of Incidences"] = no_incidences
            res["Number of Incidences per Scheme"] = incidences_per_scheme
            # Time for computing the optimal repliction schemes/partitions
            res["Incidence Wall Time (ns)"] = result["incidence_wall_time_ns"] # Wall clock time overall
            res["Incidence Time (ns)"] = result["incidence_time_ns"] # Time of parallel processes total (overhead+compute) 
            res["Incidence Computation Time (ns)"] = result["incidence_computation_time_ns"] # Time of parallel processes for computation
        else:
            print("No incidence data for " + optimizerType.name + " and " + incidenceOptimizerType.name)
        return res
        
    def create_workload(self, *, size: np.float64, put: "np.ndarray", get: "np.ndarray", ingress: "np.ndarray|None" = None, egress: "np.ndarray|None" = None, rescale: np.float64 = np.float64(1.0)) -> Workload:
        # XXX: Instantiate workload according to application region order in schemes, i.e., must use their correct index of get/ingress/egress.
        if put.shape[0] != self.no_apps:
            raise ValueError("Number of puts does not match number of applications")
        if get.shape[0] != self.no_apps:
            raise ValueError("Number of gets does not match number of applications")

        return Workload(size=size, put=put, get=get, ingress=ingress, egress=egress, rescale=rescale)

    @staticmethod
    def get_workload_file_format() -> str:
        return "The format of a workload file is: [\n{'size': <object size>,\n'put':{<region name 1>: <puts of region 1>, <region name 2>: <puts of region 2>, ...},\nget:{<region name 1>: <gets of region 1>,...}, ingress:{<region name 1>: <ingress volume of region 1>, ...}, egress: {<region name 1>: <egress volume of region 1>}},\n{...},...] "

    def load_workloads(self, *, input: str) -> List[Workload]:

        workloads = []

        # Load a list of workloads from a file
        with open(input, "r") as f:

            skipLines = False
            for i, line in enumerate(f.readlines()):
                if line.startswith("//") or len(line) == 0:
                    continue
                
                workload = json.loads(line)

                parsedWorkload = dict(
                    put = np.zeros(self.no_apps),
                    get = np.zeros(self.no_apps),
                    ingress = None,
                    egress = None,
                    size=0
                )

                # Parse accesses of application regions
                for accessCategory in ["put", "get"]:
                    if accessCategory in workload:
                        for region, count in workload[accessCategory].items():
                            if region in self.__applicationRegions:
                                parsedWorkload[accessCategory][self.__applicationRegions[region]] = count
                            else:
                                raise ValueError("Region " + region + f" in workload {accessCategory} spec. not found in application regions!\n" + "Application regions: " + str(self.__applicationRegions) + "\n" + Oracle.get_workload_file_format())
                    else:
                        print(f"WARNING: No {accessCategory} workload specified for workload {i}, assuming 0 for all regions!")
                    
                # Parse network volume of application regions
                for networkCategory in ["ingress", "egress"]:
                    if networkCategory in workload:
                        # Allocate list
                        parsedWorkload[networkCategory] = np.zeros((self.no_apps))
                        # Fill list with workload of application region at its index
                        for region, count in workload[networkCategory].items():
                            if region in self.__applicationRegions:
                                parsedWorkload[networkCategory][self.__applicationRegions[region]] = count
                            else:
                                raise ValueError("Region " + region + f" in workload {networkCategory} spec. not found in application regions!\n" + "Application regions: " + str(self.__applicationRegions) + "\n" + Oracle.get_workload_file_format())
                    else:
                        print(f"WARNING: {networkCategory} not explicitly specified in workload. Computing it based on accesses and object size!")
                    

                if "size" in workload:
                    parsedWorkload["size"] = workload["size"]
                else:
                    print(f"WARNING: No size specified for workload {i}, assuming 0!")

                workloads.append(self.create_workload(**parsedWorkload))

        if len(workloads) < 1:
            print("Input file does not contain any workloads!")

        return workloads
    
    def compute_optimal_value(self, *, optimizerType: "OptimizerType|None" = None, optimalSchemeIndex: "int|List[int]", workload: "Workload|List[Workload]") -> float:

        if isinstance(optimalSchemeIndex, int):
            optimalSchemeIndex = [optimalSchemeIndex]

        if isinstance(workload, Workload):
            workload = [workload]

        if optimizerType is not None and optimizerType.type != "None":
            print("Changing optimizer type to " + optimizerType.name)
            self.prepare_scenario(scenarioName=self.scenarioName, optimizerType=optimizerType)

        # Compute optimal value
        if optimizerType is None or self.optimizerType.type != "ILP":
            res = [self.__replicationSchemes[index].compute_cost(w) for index, w in zip(optimalSchemeIndex, workload)]
        else:
            # TODO: Use ILP to compute optimal value
            raise NotImplementedError("TODO")

        if self.verbose > 2:
            print("Optimal value:", res)

        return res

    def benchmarkQuerying(self, *, workloads: List[Workload], scenarioName: str, batchSizes, no_warmup, optimizers, translateOptSchemes, output, noWorkloadResults = False):
        
        # XXX: Assuming all workloads are scaled the same...
        rescale = workloads[0].rescale
        
        # Convert back to numpy array
        workloadsNumpy = np.array([w.equation for w in workloads])

        # Results: (optimizer, batchSize) -> (time, cost per workload)
        records = []

        for optimizer in optimizers:
            self.prepare_scenario(scenarioName=scenarioName, optimizerType=optimizer)

            if optimizer.implementation == OracleType.PYTORCH:
                workloadsQuery = workloadsNumpy
            else:
                workloadsQuery = workloads

            for batchSize in batchSizes:
                if batchSize > len(workloads):
                    if self.verbose > 0:
                        print(f"Skipping batch size {batchSize} as it is larger than the number of workloads.")
                    continue            

                print(f"Querying for {len(workloads)} workloads with batch size {batchSize} using optimizer {optimizer}")
                sys.stdout.flush()

                # Warmup
                if not no_warmup:
                    print("Warming up...")
                    numberOfWarmupQueries = 100 if not optimizer.implementation == OracleType.MOSEK else 5
                    for _ in range(numberOfWarmupQueries):
                        self.query(workloadsQuery[:1], timer=None)

                # Query
                timer=Timer(verbose=self.verbose)
                resAll=list()
                timeTotalAll=list()
                timeComputeAll=list()
                for pos in range(0, len(workloads), batchSize):
                    end = min(pos+batchSize, len(workloads))
                    if self.verbose > 1:
                        print(f"Querying for {pos}:{end} workloads")
                    timeTotal = timer.getTotalTime()
                    timeCompute = timer.getComputationTime()
                    res = self.query(workloadsQuery[pos:end], timer=timer, translateOptSchemes=translateOptSchemes, rescale=rescale)
                    if not noWorkloadResults:
                        timeTotal = timer.getTotalTime() - timeTotal
                        timeCompute = timer.getComputationTime() - timeCompute
                        resAll.extend(res)
                        timeTotalAll.append(timeTotal)
                        timeComputeAll.append(timeCompute)
                    else:
                        if len(resAll) <= 0:
                            resAll.append(list([0,0]))

                        resAll[0][0] += sum([optValue for optValue, _ in res])

                values = [optValue for optValue, _ in resAll]
                valueSum = sum(values)
                optSchemes = [optScheme if not dataclasses.is_dataclass(optScheme) else optScheme.asdict() for _, optScheme in resAll]
                if translateOptSchemes:
                    optSchemes = [{"Workload": w, "OptScheme": s} for w, s in zip(workloads, optSchemes)]

                
                if self.verbose > 2 and optimizer.implementation == OracleType.PYTORCH:
                    valuesAssert = oracle.compute_optimal_value(optimalSchemeIndex=optSchemes, optimizerType = None, workload=workloads)
                    if not np.allclose(values, valuesAssert):
                        for v, a in zip(values, valuesAssert):
                            if not np.isclose(v, a):
                                print(f"Error: {v} != {a}")

                # ["Optimizer", "BatchSize", "Time Computation", "Time Total", "Cost per workload"]
                record = {"Batch Size": batchSize, "Time Computation (ns)": timer.getComputationTime(), "Time Total (ns)": timer.getTotalTime(), "Time Computation per workload (ns)": timeComputeAll, "Time Total per workload (ns)": timeTotalAll, "Optimal value per workload": values, "Optimal scheme per workload": optSchemes, "Optimal value": valueSum}
                record.update(optimizer.get_parameters())
                record.update(self.get_precomputation_times(optimizerType=optimizer))
                records.append(record)

                if optimizer.implementation == OracleType.MOSEK:
                    print("Mosek does not support batching queries at the moment. Skipping the rest of the batch sizes...")
                    break

            # Save results after finishing each optimizer
            resultDf = pd.DataFrame(records)
            resultDf["Number of Workloads"] = len(workloads)
            
            if output is not None:
                if output.endswith(".pickle"):
                    resultDf.to_pickle(output)
                else:
                    resultDf.to_json(output)
            else:
                print(resultDf)

    def statistics(self, *, optimizers, output, scenarioName):
        records = []
        for optimizer in optimizers:
            self.prepare_scenario(scenarioName=scenarioName, optimizerType=optimizer, skipInstance=True)

            record = {
                "no_schemes": len(oracle.get_schemes()),
                "no_candidates": len(oracle.get_candidate_schemes()),
                } | optimizer.get_parameters() | oracle.get_precomputation_times()
            
            # Check if there are incidence information
            incidenceOptimizers = oracle.discoverOptimizerTypesIncidence(scenarioName=scenarioName, optimizerType=optimizer)
            if len(incidenceOptimizers) > 0:
                for incidenceOptimizer in incidenceOptimizers:
                    records.append(
                        record \
                        | oracle.get_incidence_stats(optimizerType=optimizer, incidenceOptimizerType=incidenceOptimizer) \
                        | { f"incidence_{k}":v  for k, v in incidenceOptimizer.get_parameters().items()}
                    )
            else:
                records.append(record)

        # Save results after finishing each optimizer
        resultDf = pd.DataFrame(records)
        
        if output is not None:
            if output.endswith(".pickle"):
                resultDf.to_pickle(output)
            else:
                resultDf.to_json(output)
            print(f"Saved statistics to {output}")
        else:
            print(resultDf)

def setImplementationArgs(*, implementation: "OracleType", args: Dict[str, Any]) -> Dict[str, Any]:
    implementationArgs = {}
    if implementation == OracleType.PYTORCH:
        implementationArgs["device_query"] = args["torchDeviceRayShooting"]
        implementationArgs["device_check"] = args["torchDeviceRayShooting"]
        if implementationArgs["device_query"] == "mps":
            implementationArgs["dataType"] = torch.float32
    elif implementation == OracleType.MOSEK:
        if not "networkPriceFile" in args or not "storagePriceFile" in args:
            raise ValueError("Network and storage price files must be provided for Mosek optimizer.")

        implementationArgs["networkPriceFileName"] = args["networkPriceFile"]
        implementationArgs["storagePriceFileName"] = args["storagePriceFile"]

        implementationArgs["strictReplication"]=not args['noStrictReplication']
        implementationArgs["minReplicationFactor"] = args["minReplicationFactor"]

    return implementationArgs

def compactifyForPrecomputation(precomputed_data):
    """
    Compactify in-place the precomputed data to save space.
    Only keep costWLPlane of the replication schemes.
    """

    scenario = precomputed_data["tier_advise"]["replication_factor"]
    for s in scenario.values():
        for data in s.values():
            c0 = data["candidate_partitions"][0]
            if isinstance(c0, dict):
                data["applictionRegionMapping"] = ReplicationScheme(c0).applictionRegionMapping
            elif isinstance(c0, ReplicationScheme):
                data["applictionRegionMapping"] = c0.applictionRegionMapping
                
            for candidate in data["candidate_partitions"]:
                deleteProperties = ["replicationScheme", "costWLHalfplaneRational", "inequalities"]
                for prop in deleteProperties:
                    if prop in candidate:
                        del candidate[prop]

    return precomputed_data

def createOptimizer(*, optimizer: str, args: Dict[str, Any]) -> List[OptimizerType]:
    optimizers = []
    for useClarkson in args["useClarkson"]:
        useClarkson = useClarkson == "True"
        for useGPU in args["useGPU"]:
            implementation = OracleType.PYTORCH

            useGPU = useGPU == "True"
            if "lrs" == optimizer:
                implementation = OracleType.PYTORCH
            if "ILP" == optimizer:
                implementation = OracleType.MOSEK
                # Mosek does not support GPU or Clarkson!
                if useGPU or useClarkson:
                    continue
            elif "PrimalSimplex" == optimizer:
                optimizer = MosekOptimizerType.PrimalSimplex
                implementation = OracleType.PYTORCH
            elif "InteriorPoint" == optimizer:
                optimizer = MosekOptimizerType.InteriorPoint
                implementation = OracleType.PYTORCH
            elif "Free" == optimizer:
                optimizer = MosekOptimizerType.Free
                implementation = OracleType.PYTORCH

            optimizers.append(OptimizerType(type=optimizer, useClarkson=useClarkson, useGPU=useGPU, implementation=implementation, implementationArgs=setImplementationArgs(implementation=implementation, args=args)))

    return optimizers

def benchmarkQueryAccessSetFile(*,args):
    print ("Querying the oracle for the optimum of the given access set workload file.")

    oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)

    # Discover optimizers from precomputation
    if args.addOptimizersFromInput:
        if args.optimizer[0].implementation == OracleType.NONE:
            args.optimizer.pop(0)
        args.optimizer.extend(oracle.discoverOptimizerTypes(scenarioName=scenarioName))

        for optimizer in args.optimizer:
            optimizer.implementationArgs = setImplementationArgs(implementation=optimizer.implementation, args=args.__dict__)

        print("Discovered optimizers from precomputation: ", args.optimizer)

    oracle.prepare_scenario(scenarioName=scenarioName, optimizerType=args.optimizer[0])

    # Mapping of region name to index in the arrays of the access set
    access_set_region_mapping = { a.split(":")[0]: int(a.split(":")[1]) for a in args.accessSetRegionMapping}
    # Mapping of the region name to the index in the workload
    regions = oracle.get_application_regions()
    
    for inputWorkloadFile in args.inputWorkloads:
        print(f"Loading workload file {inputWorkloadFile}")

        if inputWorkloadFile.endswith(".pickle") or inputWorkloadFile.endswith(".pickle.zip"):
            workloadTrace = pd.read_pickle(inputWorkloadFile)
        elif inputWorkloadFile.endswith(".parquet"):
            import polars as ps
            workloadTrace = ps.read_parquet(inputWorkloadFile).to_pandas()
        elif inputWorkloadFile.endswith(".csv"):
            workloadTrace = pd.read_csv(inputWorkloadFile, sep=";", converters={"get": literal_eval, "put": literal_eval, "ingress": literal_eval, "egress": literal_eval})
        else:
            raise ValueError(f"Unknown workload file format {inputWorkloadFile}")

        if args.filterTimestampByDate:
            filterTimeStamp = pd.to_datetime(args.filterTimestampByDate, format='%Y-%m-%d_%H:%M:%S')
            if workloadTrace["timestamp"].dtype == int:
                filterTimeStamp = filterTimeStamp.value
            workloadTrace = workloadTrace[workloadTrace["timestamp"] <= filterTimeStamp]

            print(f"Trace records after filtering by date (<= {args.filterTimestampByDate}): {workloadTrace.shape[0]}")

        isSingleRegionTrace = ("get" in workloadTrace.columns and \
                "put" in workloadTrace.columns and \
                "egress" in workloadTrace.columns and \
                "ingress" in workloadTrace.columns and \
                "size" in workloadTrace.columns and \
                (workloadTrace["get"].dtype == np.int64 or workloadTrace["get"].dtype == np.float64))

        if isSingleRegionTrace:
            assert len(access_set_region_mapping) == 1, f"Provide a multi-region workload trace or a mapping of the access set with multiple regions. isSingleRegionTrace={isSingleRegionTrace} access_set_region_mapping={access_set_region_mapping}"

        if isSingleRegionTrace:
            r = list(access_set_region_mapping.keys())[0]

        workloads = []
        for w in workloadTrace.itertuples():
            get = np.zeros(oracle.no_apps)
            put = np.zeros(oracle.no_apps)
            ingress = np.zeros(oracle.no_apps)
            egress = np.zeros(oracle.no_apps)

            if isSingleRegionTrace:
                size = w.size
                get[regions[r]] = w.get
                put[regions[r]] = w.put
                ingress[regions[r]] = w.ingress * args.ingressScale
                egress[regions[r]] = w.egress * args.egressScale
            else:
                size = w.size
                for (r, access_set_i) in access_set_region_mapping.items():
                    get[regions[r]] = w.get[access_set_i]
                    put[regions[r]] = w.put[access_set_i]
                    ingress[regions[r]] = w.ingress[access_set_i] * args.ingressScale
                    egress[regions[r]] = w.egress[access_set_i] * args.egressScale
            # Only add workload if there is at least one access
            if np.max(get) > 0 or np.max(put) > 0 or np.max(ingress) > 0 or np.max(egress) > 0:
                workloads.append(oracle.create_workload(size=size*args.sizeScale, put=put, get=get, ingress=ingress, egress=egress, rescale=args.rescale))

            if len(workloads) >= args.noWorkloads:
                break

        output = args.output + f"_{inputWorkloadFile.split('/')[-1].split('.')[0]}_accessSet_{len(args.accessSetRegionMapping)}"

        print(f"Processing {len(workloads)} workloads of file {inputWorkloadFile}")
        oracle.benchmarkQuerying(workloads=workloads, scenarioName=scenarioName, optimizers=args.optimizer, batchSizes=args.batchSizes, no_warmup=args.no_warmup, translateOptSchemes=args.translateOptSchemes, output=output, noWorkloadResults=args.noWorkloadResults)


def __main__():

    parser = argparse.ArgumentParser(description="SkyPie optimizer oracle for computing and querying optimal object repliction for any given workload.")
    parser.add_argument("command", type=str, help="Command to execute: 'compute', 'computeNeighbors', 'queryRandom', 'queryFile','queryAccessSetFile', 'listRegions', 'toPickle', 'toJson'.")
    parser.add_argument("input", type=str, help="Input file name.")
    parser.add_argument("scenario", type=str, help="Scenario name.")
    parser.add_argument("--verbose", type=int, help="Verbose level.", default=0)
    parser.add_argument("--validate", help="Validate the computed optimal repliction schemes/partitions.", action='store_true')
    parser.add_argument("--dump", help="Dump the input for cdd.", action='store_true')
    #parser.add_argument("--expectedRedundant", type=int, nargs='+', help='<Required> Set flag')
    parser.add_argument("--optimizer", type=str, nargs='+', help="Optimizer to use. Either 'Lrs' or type of Mosek's optimizer: 'InteriorPoint', 'PrimalSimplex', 'Free'. Also 'Candidates' is a valid choice for querying.", default=[])
    parser.add_argument("--useClarkson", type=str, nargs='+', help="Use Clarkson's algorithm for computing the optimal repliction schemes/partitions.", default=["False"])
    parser.add_argument("--useGPU", type=str, nargs='+', help="Use GPU for computing the optimal repliction schemes/partitions.", default=["False"])
    parser.add_argument("--torchDeviceRayShooting", type=str, help="Torch device for ray shooting.", default="cpu")
    parser.add_argument("--repairInputData", help="Repair input data.", action="store_true")
    parser.add_argument("--output", type=str, help="Output file name.")
    parser.add_argument("--noWorkloads", type=int, help="Number of workloads to generate.", default=1024)
    parser.add_argument("--workloadSeed", type=int, help="Seed for generating workloads.", default=42)
    parser.add_argument("--workloadRange", type=int, nargs=2, help="Range of workload sizes.", default=[0, 100])
    parser.add_argument("--batchSizes", type=int, nargs='+', help="Batch sizes for querying.", default=[1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024])
    parser.add_argument("--networkPriceFile", type=str, help="Network price file name.")
    parser.add_argument("--storagePriceFile", type=str, help="Storage price file name.")
    parser.add_argument("--optimizerThreads", type=int, help="Number of threads for the optimizer.", default=10)
    parser.add_argument("--nonnegative", help="Use nonnegative constraints.", action='store_true', default=False)
    parser.add_argument("--useCandidates", help="Use candidates for querying.", action='store_true')
    parser.add_argument("--addOptimizersFromInput", help="Discover additional optimizers from file.", action='store_true')
    parser.add_argument("--inputWorkloads", type=str, nargs="+", help="List of input workloads file names.")
    parser.add_argument("--translateOptSchemes", help="Translate the IDs of  optimal schemes to the detailed definition.", action='store_true')
    parser.add_argument("--no_warmup", help="Do not warmup the optimizer.", action='store_true')
    parser.add_argument("--dSizes", type=int, help="Division size for the divide-and-pause computation.", nargs='+', default=[None])
    parser.add_argument("--compiter", type=int, help="Number of iterations for the divide-and-pause computation.", default=100)
    parser.add_argument("--candidateLimit", type=int, help="Limit the number of candidates for the (pre)computation.")
    parser.add_argument("--processes", type=int, help="Number of processes for the computation.", default=1)
    parser.add_argument("--compact", help="Compactify the input data.", action="store_true", default=False)
    parser.add_argument("--skip", type=int, help="Skip the first n workloads.", default=0)
    parser.add_argument("--queryStepSize", type=int, help="Step size for querying.", default=0)
    parser.add_argument("--accessSetRegionMapping", type=str, nargs='+', help="Access set region mapping: region name to index in array.", default=[])
    parser.add_argument("--noStrictReplication", help="Do not force replication factor to be exactly f, but allow higher replication as well.", action='store_true', default=False)
    parser.add_argument("--rescale", help="Rescale the input data.", type=np.float64, default=1.0)
    parser.add_argument("--filterTimestampByDate", type=str, help="Filter the timestamp by date.", default=None)
    parser.add_argument("--computeNeighborsForOptimizer", type=str, nargs="+", help="Compute neighbors for the given optimizer.", default=None)
    parser.add_argument("--outputStats", type=str, help="Output stats file name.", default=None)
    parser.add_argument("--sizeScale", type=float, help="Scale the size of the objects.", default=1.0)
    parser.add_argument("--ingressScale", type=float, help="Scale the ingress volume.", default=1.0)
    parser.add_argument("--egressScale", type=float, help="Scale the egress volume.", default=1.0)
    parser.add_argument("--minReplicationFactor", type=int, help="Override minimum replication factor.", default=0)
    parser.add_argument("--noWorkloadResults", help="Do not save results for individual worklaods!", default=False, action="store_true")

    args = parser.parse_args()

    optimizers = []
    for optimizer in args.optimizer:
        optimizers.extend(createOptimizer(optimizer=optimizer, args=args.__dict__))

    if args.useCandidates:
        optimizers.extend(createOptimizer(optimizer="Candidates", args=args.__dict__))

    args.optimizer = optimizers if len(optimizers) > 0 else [OptimizerType(type="None", useClarkson=False, useGPU=False)]
    if args.verbose > 0:
        print(f"Using optimizer: ", args.optimizer)

    inputFileName = args.input
    scenarioName = args.scenario

    if args.command in ["toJson","toJSON", "toPickle"]:
        readMode = "rb" if "pickle" in inputFileName else "r"
        if inputFileName.endswith("bz2"):
            inF = bz2.BZ2File(inputFileName, readMode)
        else:
            inF = open(inputFileName, readMode)
        if "pickle" in inputFileName:
            data = pickle.load(inF)
        elif "json" in inputFileName:
            data = json.load(inF, cls=EnhancedJSONDecoder)
        else:
            print("Input file must be json or pickle!")
            exit(1)

        inF.close()

        if args.compact:
            data = compactifyForPrecomputation(data)

        outputFilename = args.output
        if args.command in ["toJson","toJSON"]:
            #outputFilename = "".join(inputFileName.split(".")[:-1]) + ".json"
            with open(outputFilename, "w") as outF:
                json.dump(data, outF, cls=EnhancedJSONEncoder, indent=4)
        elif args.command == "toPickle":
            #outputFilename = "".join(inputFileName.split(".")[:-1]) + ".pickle"
            with open(outputFilename, "wb") as outF:
                pickle.dump(data, outF)
        else:
            raise Exception("Unknown command!")

        print(f"Converted to {outputFilename}")

    elif args.command == "listRegions":
        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)
        oracle.prepare_scenario(scenarioName=scenarioName, optimizerType=args.optimizer[-1])
        regions = list(oracle.get_application_regions().keys())
        regions.sort()
        print(f"Available regions ({len(regions)}):")
        print(regions)

    elif args.command == "statisticsPrecomputation":
        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)
        
        if args.addOptimizersFromInput:
            args.optimizer.extend(oracle.discoverOptimizerTypes(scenarioName=scenarioName))

        oracle.statistics(scenarioName=scenarioName, optimizers=args.optimizer, output=args.output)

    elif args.command == "mergeScenarios":
        pass

    elif args.command == "testWorkloadCost":
        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)
        oracle.prepare_scenario(scenarioName=scenarioName, optimizerType=args.optimizer[-1])

        scheme = oracle.get_schemes()[0]
        assert(scheme.cost.storage == scheme.cost.equation[1])
        no_apps = oracle.no_apps
        # Test size price
        w = oracle.create_workload(size=1, put=np.zeros(no_apps), get=np.zeros(no_apps))
        value = oracle.compute_optimal_value(optimalSchemeIndex=0, workload=w)
        expected = scheme.cost.storage
        if value != expected:
            print(f"Error storage: {value} == {expected}")

        for i in range(no_apps):
            # Test put and ingress price
            put=np.zeros(no_apps)
            get=np.zeros(no_apps)
            put[i] = 1
            w = oracle.create_workload(size=1, put=put, get=get)
            value = oracle.compute_optimal_value(optimalSchemeIndex=0, workload=w)
            expected = scheme.cost.storage + scheme.cost.ingress[i] + scheme.cost.put
            if value != expected:
                print(f"Error put + ingress + storage: {value} != {expected}")

            put[i] = 0
            get[i] = 1
            w = oracle.create_workload(size=1, put=put, get=get)
            value = oracle.compute_optimal_value(optimalSchemeIndex=0, workload=w)
            expected = scheme.cost.storage + scheme.cost.egress[i] + scheme.cost.get[i]
            if value != expected:
                print(f"Error get + ingress + storage: {value} != {expected}")

    elif args.command == "queryAccessSetFile":
        benchmarkQueryAccessSetFile(args=args)
    elif args.command == "queryFile":
        print ("Querying the oracle for the optimum of the given workload file.")

        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)
        oracle.prepare_scenario(scenarioName=scenarioName, optimizerType=args.optimizer[-1])

        # Discover optimizers from precomputation
        if args.addOptimizersFromInput:
            args.optimizer.extend(oracle.get_precomputation_optimizers())

            for optimizer in args.optimizer:
                optimizer.implementationArgs = setImplementationArgs(implementation=optimizer.implementation, args=args.__dict__)

            print("Discovered optimizers from precomputation: ", args.optimizer)

        # Load workloads from file
        workloads = oracle.load_workloads(input=args.inputWorkloads)

        oracle.benchmarkQuerying(workloads=workloads, scenarioName=scenarioName, optimizers=args.optimizer, batchSizes=args.batchSizes, no_warmup=args.no_warmup, translateOptSchemes=args.translateOptSchemes, output=args.output, noWorkloadResults=args.noWorkloadResults)

    elif args.command == "queryRandom":
        print ("Querying the oracle for the optimum for synthetic workloads")

        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)

        # Discover optimizers from precomputation
        if args.addOptimizersFromInput:
            for i in range(len(args.optimizer)):
                if args.optimizer[i].implementation == OracleType.NONE:
                    del args.optimizer[i]
            args.optimizer.extend(oracle.discoverOptimizerTypes(scenarioName))

            for optimizer in args.optimizer:
                optimizer.implementationArgs = setImplementationArgs(implementation=optimizer.implementation, args=args.__dict__)

            print("Discovered optimizers from precomputation: ", args.optimizer)

        oracle.prepare_scenario(scenarioName=scenarioName, optimizerType=args.optimizer[-1])

        # Randomly generate workloads
        noApps = oracle.no_apps
        rnd = np.random.default_rng(seed=args.workloadSeed)
        # Generate random size, put and get
        size = 1 + 2*noApps
        workloads = rnd.random(size=(args.noWorkloads, size))
        # Shift into given range
        workloads = (workloads * (args.workloadRange[1] - args.workloadRange[0])) + args.workloadRange[0]
        # Instantiate workloads
        workloads = [oracle.create_workload(size=w[0], put=w[1:1+noApps], get=w[1+noApps:1+2*noApps]) for w in workloads]
        # Convert back to numpy array
        #workloadsNumpy = np.array([w.equation for w in workloads])

        if args.queryStepSize != 0:
            for queryStep in range(args.skip, len(workloads), args.queryStepSize):
                print(f"Querying for {queryStep}:{queryStep+args.queryStepSize} workloads")
                sys.stdout.flush()
                oracle.benchmarkQuerying(workloads=workloads[queryStep:queryStep+args.queryStepSize], scenarioName=scenarioName, optimizers=args.optimizer, batchSizes=args.batchSizes, no_warmup=args.no_warmup, translateOptSchemes=args.translateOptSchemes, output=args.output, noWorkloadResults=args.noWorkloadResults)
        else:
            oracle.benchmarkQuerying(workloads=workloads[args.skip:], scenarioName=scenarioName, optimizers=args.optimizer, batchSizes=args.batchSizes, no_warmup=args.no_warmup, translateOptSchemes=args.translateOptSchemes, output=args.output, noWorkloadResults=args.noWorkloadResults)

    elif args.command == "compute" or args.command == 'computeNeighbors':

        doNormalCompute = args.command == "compute"

        if doNormalCompute:
            print(f"Computing optima for {scenarioName} using {inputFileName}...")
        else:
            print(f"Computing neighbors for {scenarioName} using {inputFileName}...")
        sys.stdout.flush()

        oracle = Oracle(inputFileName=inputFileName, verbose=args.verbose)
        # Create oracle instance by prepare_scenario
        scenarioArgs = {"scenarioName": scenarioName, "repairInputData": args.repairInputData}
        oracle.prepare_scenario(**scenarioArgs, optimizerType=args.optimizer[-1])

        if args.verbose >= 0:
            print("Oracle instance created. Computing...")

        sys.stdout.flush()

        algoArgs = {
            k:args.__dict__[k] for k in ["torchDeviceRayShooting", "normalize", "optimizerThreads", "nonnegative"] if k in args 
        }

        # Find which optimizers were used for the first precomputation step
        optimizersPrecomputation = oracle.discoverOptimizerTypes(scenarioName)

        if args.computeNeighborsForOptimizer and len(args.computeNeighborsForOptimizer) > 0:
            optimizersPrecomputation = [o for o in optimizersPrecomputation if o.name in args.computeNeighborsForOptimizer]

        for dsize in args.dSizes:
            for optimizer in args.optimizer:
                if not optimizer.useClarkson and optimizer.useGPU:
                    print("Only Clarkson mode supports GPU. Skipping ", optimizer.name, "...")
                    continue

                if args.verbose >= 0:
                    print(f"Computing optima with optimizer {optimizer.name}")
                    sys.stdout.flush()

                if doNormalCompute:
                    oracle.compute_optima(optimizerType=optimizer, divisionSize=dsize, iterations=args.compiter, candidateLimit=args.candidateLimit, processes=args.processes, algoArgs=algoArgs)
                    if args.verbose >= 0:
                        print(f"Computed with optimizer {optimizer.name}")
                        sys.stdout.flush()
                    if args.validate:
                        #oracle.validate(baseline=, comp=, dump=args.dump)
                        # TODO
                        pass
                    if args.output is not None:
                        oracle.save(args.output)
                    if args.outputStats:
                            oracle.statistics(optimizers=args.optimizer, output=args.outputStats, scenarioName=scenarioName)

                else:
                    print(f"Computing neighbors for precomputed optimizers {optimizersPrecomputation}")
                    for optimizerPrecomputation in optimizersPrecomputation:
                        oracle.prepare_scenario(**scenarioArgs, optimizerType=optimizerPrecomputation, skipInstance=True)
                        oracle.compute_neighborhood(optimizerType=optimizer, divisionSize=dsize, iterations=args.compiter, processes=args.processes, algoArgs=algoArgs)
                        if args.verbose >= 0:
                            print(f"Computed with optimizer {optimizer.name} based on initial precomputation of {optimizerPrecomputation.name}")
                            sys.stdout.flush()

                        if args.output is not None:
                            oracle.save(args.output)
                        if args.outputStats:
                            oracle.statistics(optimizers=optimizersPrecomputation, output=args.outputStats, scenarioName=scenarioName)


    else:
        raise ValueError(f"Unknown command {args.command}")

if __name__ == "__main__":
    __main__()